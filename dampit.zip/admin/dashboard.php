<?php
session_start();
include '../config/database.php';

// Cek apakah yang login adalah ADMIN
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

// Ambil daftar semua pegawai untuk Dropdown
$query_pegawai = mysqli_query($koneksi, "SELECT * FROM users WHERE role='pegawai' ORDER BY nama ASC");

// Default Bulan & Tahun
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
$id_pegawai_pilih = isset($_GET['id_pegawai']) ? $_GET['id_pegawai'] : '';

// Jika ada pegawai yang dipilih, ambil datanya
$data_kegiatan = [];
$nama_pegawai_terpilih = "Pilih Pegawai Dulu";

if (!empty($id_pegawai_pilih)) {
    // Ambil Nama Pegawai
    $q_nama = mysqli_query($koneksi, "SELECT nama FROM users WHERE id='$id_pegawai_pilih'");
    $d_nama = mysqli_fetch_assoc($q_nama);
    $nama_pegawai_terpilih = $d_nama['nama'];

    // Ambil Kegiatan Pegawai Tersebut
    $query_kegiatan = mysqli_query($koneksi, "SELECT * FROM kegiatan WHERE user_id='$id_pegawai_pilih' AND MONTH(tanggal)='$bulan' AND YEAR(tanggal)='$tahun'");
    while ($row = mysqli_fetch_assoc($query_kegiatan)) {
        $data_kegiatan[$row['tanggal']] = $row;
    }
}

// Logic Kalender
$jumlah_hari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
$tgl_pertama = "$tahun-$bulan-01";
$hari_pertama = date('w', strtotime($tgl_pertama));

$nama_bulan = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .kalender-grid { display: flex; flex-wrap: wrap; }
        .kalender-col {
            width: 14.28%; border: 1px solid #dee2e6; min-height: 120px;
            position: relative; background-color: white; padding: 5px; cursor: pointer;
        }
        .kalender-col:hover { background-color: #f8f9fa; }
        .header-hari { width: 14.28%; text-align: center; font-weight: bold; background-color: #343a40; color: white; padding: 10px 0; }
        
        .bg-locked { background-color: #e2e6ea !important; border-left: 5px solid #6c757d; } 
        .bg-final { background-color: #f8d7da !important; border-left: 5px solid #dc3545; }
        
        .text-tgl { font-weight: bold; font-size: 1.1rem; }
        .badge-status { font-size: 0.7rem; display: block; margin-top: 5px; }
        .text-ket { font-size: 0.8rem; color: #555; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;}
        .label-jenis { font-size: 0.75rem; font-weight: bold; color: #0d6efd; margin-bottom: 2px; display: block; }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand p-0" href="dashboard.php">
                <img src="../assets/img/logo_dampit.png" alt="DaMPiT" 
                     style="height: 55px; background: white; padding: 5px 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
            </a>
            
            <div class="navbar-nav me-auto ms-4">
                <a class="nav-link text-white fw-bold active" href="dashboard.php">Dashboard</a>
                <a class="nav-link text-white opacity-75 hover-opacity-100" href="cetak_rekap.php">🖨️ Cetak Rekap</a>
                <a class="nav-link text-white opacity-75 hover-opacity-100" href="users.php">👥 Kelola User</a>
            </div>

            <div class="d-flex text-white align-items-center">
                <span class="me-3">Halo, Admin</span>
                <a href="../logout.php" class="btn btn-sm btn-outline-light fw-bold">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        
        <div class="card shadow-sm mb-4">
            <div class="card-body bg-white">
                <form method="GET" class="row g-3 align-items-center">
                    <div class="col-auto">
                        <label class="fw-bold">Pilih Pegawai:</label>
                    </div>
                    <div class="col-md-4">
                        <select name="id_pegawai" class="form-select" onchange="this.form.submit()">
                            <option value="">-- Pilih Nama Pegawai --</option>
                            <?php while($p = mysqli_fetch_assoc($query_pegawai)): ?>
                                <option value="<?= $p['id'] ?>" <?= ($id_pegawai_pilih == $p['id']) ? 'selected' : '' ?>>
                                    <?= $p['nama'] ?> (NIP: <?= $p['nip'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <input type="hidden" name="bulan" value="<?= $bulan ?>">
                    <input type="hidden" name="tahun" value="<?= $tahun ?>">
                </form>
            </div>
        </div>

        <?php if(empty($id_pegawai_pilih)): ?>
            <div class="alert alert-info text-center py-5">
                <h4>👈 Silakan pilih pegawai terlebih dahulu untuk melihat kalender.</h4>
            </div>
        <?php else: ?>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="?id_pegawai=<?= $id_pegawai_pilih ?>&bulan=<?= date('m', mktime(0,0,0,$bulan-1,1,$tahun)) ?>&tahun=<?= date('Y', mktime(0,0,0,$bulan-1,1,$tahun)) ?>" class="btn btn-outline-dark btn-sm">◀ Prev</a>
                <h4 class="fw-bold m-0"><?= $nama_bulan[$bulan] ?> <?= $tahun ?> - <?= $nama_pegawai_terpilih ?></h4>
                <a href="?id_pegawai=<?= $id_pegawai_pilih ?>&bulan=<?= date('m', mktime(0,0,0,$bulan+1,1,$tahun)) ?>&tahun=<?= date('Y', mktime(0,0,0,$bulan+1,1,$tahun)) ?>" class="btn btn-outline-dark btn-sm">Next ▶</a>
            </div>

            <div class="card shadow border-0 mb-5">
                <div class="card-body p-0">
                    <div class="d-flex text-center">
                        <div class="header-hari">Minggu</div><div class="header-hari">Senin</div><div class="header-hari">Selasa</div>
                        <div class="header-hari">Rabu</div><div class="header-hari">Kamis</div><div class="header-hari">Jumat</div><div class="header-hari">Sabtu</div>
                    </div>
                    
                    <div class="kalender-grid">
                        <?php
                        for ($i = 0; $i < $hari_pertama; $i++) echo '<div class="kalender-col bg-light"></div>';

                        for ($tgl = 1; $tgl <= $jumlah_hari; $tgl++) {
                            $tgl_full = sprintf("%04d-%02d-%02d", $tahun, $bulan, $tgl);
                            
                            $warna = ""; $konten = ""; $status = ""; $id_kegiatan = ""; 
                            $ket = ""; $alasan = ""; $history_html = ""; $jenis = "";

                            if (isset($data_kegiatan[$tgl_full])) {
                                $row = $data_kegiatan[$tgl_full];
                                $status = $row['status'];
                                $id_kegiatan = $row['id'];
                                $ket = htmlspecialchars($row['keterangan']);
                                // AMBIL JENIS KEGIATAN (NEW)
                                $jenis = htmlspecialchars($row['jenis']);
                                
                                $alasan = isset($row['alasan_update']) ? htmlspecialchars($row['alasan_update']) : '-';
                                $history = isset($row['history_log']) ? htmlspecialchars($row['history_log']) : '';
                                $history_html = str_replace("\n", "<br>", $history);

                                if ($status == 'LOCKED') {
                                    $warna = "bg-locked";
                                    $konten = "<span class='badge bg-secondary badge-status'>🔒 Terkunci</span>";
                                } else {
                                    $warna = "bg-final";
                                    $konten = "<span class='badge bg-danger badge-status'>🚫 Final</span>";
                                }
                                // TAMPILKAN JENIS DI KALENDER
                                $konten .= "<div class='label-jenis mt-2'>$jenis</div>";
                                $konten .= "<div class='text-ket'>$ket</div>";
                            }
                        ?>
                            <div class="kalender-col <?= $warna ?>" 
                                 onclick="modalAdmin('<?= $tgl_full ?>', '<?= $status ?>', '<?= $id_kegiatan ?>', '<?= $ket ?>', '<?= $alasan ?>', '<?= $history_html ?>', '<?= $jenis ?>')">
                                <span class="text-tgl"><?= $tgl ?></span>
                                <?= $konten ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>

        <?php endif; ?>

    </div>

    <div class="modal fade" id="modalAdmin" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title">🛡️ Kontrol Admin</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Tanggal:</strong> <span id="admTgl"></span></p>
                    <p><strong>Jenis:</strong> <span id="admJenis" class="badge bg-primary"></span></p>
                    <p><strong>Keterangan:</strong> <span id="admKet" class="fw-bold"></span></p>
                    
                    <div id="blokAlasan" style="display:none;" class="alert alert-danger py-2">
                        <small class="fw-bold">Alasan Update Pegawai:</small><br>
                        <span id="admAlasan"></span>
                    </div>

                    <div class="mt-3">
                        <small class="fw-bold text-muted">📜 Riwayat Perubahan:</small>
                        <div class="bg-light border rounded p-2 small" style="max-height: 150px; overflow-y: auto; font-family: monospace;">
                            <span id="admHistory"></span>
                        </div>
                    </div>

                    <hr>
                    <a href="#" id="btnReset" class="btn btn-warning w-100 fw-bold mb-2">
                        🔓 BUKA KUNCI
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modal = new bootstrap.Modal(document.getElementById('modalAdmin'));

        function modalAdmin(tgl, status, id, ket, alasan, history, jenis) { // Terima jenis
            if (status === '') return;

            document.getElementById('admTgl').innerText = tgl;
            document.getElementById('admKet').innerText = ket;
            document.getElementById('admAlasan').innerText = alasan;
            document.getElementById('admHistory').innerHTML = history;
            
            // Set Jenis Kegiatan di Modal
            document.getElementById('admJenis').innerText = jenis;

            if(alasan && alasan !== '-') {
                document.getElementById('blokAlasan').style.display = 'block';
            } else {
                document.getElementById('blokAlasan').style.display = 'none';
            }

            document.getElementById('btnReset').href = "proses_reset.php?id=" + id;
            modal.show();
        }
    </script>
</body>
</html>