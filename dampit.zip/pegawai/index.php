<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pegawai') {
    header("Location: ../index.php");
    exit;
}

$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

$id_user = $_SESSION['id'];
$query_kegiatan = mysqli_query($koneksi, "SELECT * FROM kegiatan WHERE user_id='$id_user' AND MONTH(tanggal)='$bulan' AND YEAR(tanggal)='$tahun'");

$data_kegiatan = [];
while ($row = mysqli_fetch_assoc($query_kegiatan)) {
    $data_kegiatan[$row['tanggal']] = $row;
}

$jumlah_hari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
$tgl_pertama = "$tahun-$bulan-01";
$hari_pertama = date('w', strtotime($tgl_pertama));

$nama_bulan = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pegawai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .kalender-grid { display: flex; flex-wrap: wrap; }
        .kalender-col {
            width: 14.28%; border: 1px solid #dee2e6; min-height: 120px;
            position: relative; background-color: white; padding: 8px; cursor: pointer; transition: 0.2s;
        }
        .kalender-col:hover { background-color: #e9ecef; z-index: 5; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .header-hari { width: 14.28%; text-align: center; font-weight: bold; background-color: #f8f9fa; padding: 10px 0; border: 1px solid #dee2e6; }
        
        .bg-locked { background-color: #e2e6ea !important; border-left: 5px solid #6c757d; } 
        .bg-final { background-color: #f8d7da !important; border-left: 5px solid #dc3545; }
        
        .status-badge { display: block; margin-top: 5px; font-size: 0.75rem; padding: 4px; border-radius: 4px; }
        .badge-abu { background-color: #6c757d; color: white; }
        .badge-merah { background-color: #dc3545; color: white; }

        .text-tgl { font-weight: bold; font-size: 1.2rem; display: block; margin-bottom: 5px; }
        .text-keterangan { font-size: 0.85rem; color: #333; line-height: 1.2; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        .tgl-kiri { background-color: #fcfcfc; cursor: default; }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container">
            <a class="navbar-brand p-0" href="index.php">
                <img src="../assets/img/logo_dampit.png" alt="DaMPiT" 
                     style="height: 55px; background: white; padding: 5px 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
            </a>
            
            <div class="navbar-nav me-auto ms-4">
                <a class="nav-link text-white fw-bold active" href="index.php">Kalender</a>
                <a class="nav-link text-white opacity-75 hover-opacity-100" href="cetak.php">🖨️ Cetak Laporan</a>
            </div>

            <div class="d-flex text-white align-items-center">
                <span class="me-3">Halo, <?php echo $_SESSION['nama']; ?></span>
                <a href="../logout.php" class="btn btn-sm btn-light text-primary fw-bold">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4 mb-5">
        
        <div class="d-flex justify-content-between align-items-center mb-3">
            <a href="?bulan=<?= date('m', mktime(0,0,0,$bulan-1,1,$tahun)) ?>&tahun=<?= date('Y', mktime(0,0,0,$bulan-1,1,$tahun)) ?>" class="btn btn-outline-primary"><i class="bi bi-chevron-left"></i> Prev</a>
            <h3 class="fw-bold m-0"><?= $nama_bulan[$bulan] ?> <?= $tahun ?></h3>
            <a href="?bulan=<?= date('m', mktime(0,0,0,$bulan+1,1,$tahun)) ?>&tahun=<?= date('Y', mktime(0,0,0,$bulan+1,1,$tahun)) ?>" class="btn btn-outline-primary">Next <i class="bi bi-chevron-right"></i></a>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="d-flex bg-light text-center border-bottom">
                    <div class="header-hari">Minggu</div><div class="header-hari">Senin</div><div class="header-hari">Selasa</div>
                    <div class="header-hari">Rabu</div><div class="header-hari">Kamis</div><div class="header-hari">Jumat</div><div class="header-hari">Sabtu</div>
                </div>
                
                <div class="kalender-grid">
                    <?php
                    for ($i = 0; $i < $hari_pertama; $i++) {
                        echo '<div class="kalender-col tgl-kiri"></div>';
                    }

                    for ($tgl = 1; $tgl <= $jumlah_hari; $tgl++) {
                        $tgl_full = sprintf("%04d-%02d-%02d", $tahun, $bulan, $tgl);
                        
                        $warna_class = ""; $konten = ""; $status_db = ""; 
                        $keterangan_full = ""; 
                        $alasan_full = ""; // Variabel baru untuk alasan

                        if (isset($data_kegiatan[$tgl_full])) {
                            $row = $data_kegiatan[$tgl_full];
                            $status_db = $row['status'];
                            $keterangan_full = htmlspecialchars($row['keterangan']);
                            // Ambil alasan update (jika ada)
                            $alasan_full = isset($row['alasan_update']) ? htmlspecialchars($row['alasan_update']) : '-';
                            
                            $label_ket = "<div class='text-keterangan'>". $row['keterangan'] ."</div>";

                            if ($status_db == 'LOCKED') {
                                $warna_class = "bg-locked"; 
                                $konten = $label_ket . "<span class='status-badge badge-abu'>🔒 Terkunci</span>";
                            } elseif ($status_db == 'FINAL') {
                                $warna_class = "bg-final"; 
                                $konten = $label_ket . "<span class='status-badge badge-merah'>🚫 Final</span>";
                            }
                        }
                    ?>
                        <div class="kalender-col <?= $warna_class ?>" 
                             onclick="klikTanggal('<?= $tgl_full ?>', '<?= $status_db ?>', '<?= $keterangan_full ?>', '<?= $alasan_full ?>')">
                            
                            <span class="text-tgl"><?= $tgl ?></span>
                            <?= $konten ?>
                        </div>

                    <?php } ?>
                </div>
            </div>
        </div>
        
        <div class="mt-3 d-flex gap-3">
            <small><i class="bi bi-square"></i> Putih: Bebas</small>
            <small><i class="bi bi-square-fill text-secondary"></i> Abu: Terkunci</small>
            <small><i class="bi bi-square-fill text-danger"></i> Merah: Final</small>
        </div>
    </div>

    <div class="modal fade" id="modalRingkasan" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-secondary text-white" id="modalHeader">
                    <h5 class="modal-title">📄 Detail Kegiatan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-2"><strong>Tanggal:</strong> <span id="viewTanggal"></span></div>
                    <div class="mb-3"><strong>Status:</strong> <span id="viewStatusBadge"></span></div>
                    
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">Keterangan Kegiatan:</label>
                        <div class="p-3 bg-light border rounded" id="viewKeterangan"></div>
                    </div>

                    <div id="blokAlasan" class="mb-3" style="display: none;">
                        <label class="fw-bold text-danger small">Alasan Update:</label>
                        <div class="p-3 bg-danger bg-opacity-10 border border-danger rounded text-danger" id="viewAlasan"></div>
                    </div>

                    <div id="pesanKesempatan" class="mt-3 text-muted small"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                    
                    <a href="#" id="btnUpdate" class="btn btn-warning">✏️ Update Data</a>

                    <a href="https://wa.me/628123456789?text=Halo Admin, saya ingin mengajukan pembukaan kunci tanggal..." 
                       target="_blank" 
                       id="btnAdmin" 
                       class="btn btn-danger" 
                       style="display: none;">
                       <i class="bi bi-whatsapp"></i> Ajukan ke Admin
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modalRingkasan = new bootstrap.Modal(document.getElementById('modalRingkasan'));

        function klikTanggal(tanggal, status, keterangan, alasan) {
            // Reset Tampilan
            document.getElementById('viewTanggal').innerText = tanggal;
            document.getElementById('viewKeterangan').innerText = keterangan;
            document.getElementById('blokAlasan').style.display = 'none';
            document.getElementById('btnUpdate').style.display = 'none';
            document.getElementById('btnAdmin').style.display = 'none';
            
            const badge = document.getElementById('viewStatusBadge');
            const pesan = document.getElementById('pesanKesempatan');
            const header = document.getElementById('modalHeader');

            if (status === 'LOCKED') {
                // LOGIKA WARNA ABU
                badge.className = 'badge bg-secondary';
                badge.innerText = 'LOCKED (Terkunci)';
                pesan.innerText = '* Anda masih memiliki kesempatan 1x Update.';
                
                header.className = 'modal-header bg-secondary text-white';
                
                // Tampilkan Tombol Update
                document.getElementById('btnUpdate').style.display = 'block';
                document.getElementById('btnUpdate').href = "input_kegiatan.php?tanggal=" + tanggal + "&mode=update";
                
                modalRingkasan.show();
            } 
            else if (status === 'FINAL') {
                // LOGIKA WARNA MERAH
                badge.className = 'badge bg-danger';
                badge.innerText = 'FINAL (Tidak Bisa Diedit)';
                pesan.innerText = '* Data sudah final. Hubungi admin jika ada kesalahan fatal.';
                
                header.className = 'modal-header bg-danger text-white';

                // Tampilkan Alasan
                document.getElementById('blokAlasan').style.display = 'block';
                document.getElementById('viewAlasan').innerText = alasan;

                // Tampilkan Tombol Admin
                document.getElementById('btnAdmin').style.display = 'block';
                // Update link WA dengan tanggal dinamis
                document.getElementById('btnAdmin').href = "https://wa.me/6282268097901?text=Halo Admin, mohon bantuannya untuk membuka kunci tanggal " + tanggal + " karena ada kesalahan input.";

                modalRingkasan.show();
            } 
            else {
                // Input Baru
                let konfirmasi = confirm("Ingin mengisi KEGIATAN di tanggal " + tanggal + "?");
                if(konfirmasi) {
                     window.location.href = "input_kegiatan.php?tanggal=" + tanggal + "&mode=baru";
                }
            }
        }
    </script>
</body>
</html>